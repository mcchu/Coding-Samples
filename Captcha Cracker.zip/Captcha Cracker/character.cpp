#include <iostream>
#include <fstream>
#include <vector>
#include <deque>
#include <cstdlib>
#include "character.h"
#include "point.h"
#include "bmplib.h"

using namespace std;

Character::Character(unsigned char (*myimage)[256], int ulr, int ulc, int h, int w )
{
    image = myimage;
    ul_r = ulr;
    ul_c = ulc;
    height = h;
    width = w;
} 
Character::~Character(){};

void Character::perform_tests()
{
    calc_bit_quads();				//finds the bit quads
    area = calc_area();				//finds area of box
    perimeter = calc_perimeter();		//finds perimeter of bbox		
    euler = calc_euler_number();		//calcs euler's number
    v_com = calc_v_spatial_moment();		//calcs the vertical centroids
    h_com = calc_h_spatial_moment();		//calcs horizontal centroid
    v_sym = calc_vert_sym();          		//calcs vertical symmetry
    h_sym = calc_horz_sym();			//calcs horizontal symmetry
    aspect_ratio = calc_aspect_ratio();		//calcs aspect ratio
}

int *Character::calc_bit_quads()
{
    for (int i = 0; i < 6; i++)
    {
	bit_quad[i] = 0;		//initialize my bit quad indicators
    }

	//bit_quad[0] = 0 black; bit_quad[1] = 1 b; bit_quad[2] = 2 (non-d) b; 
	//bit_quad[3] = 3 b; 	 bit_quad[4] = 4 b; bit_quad[5] = 2 diag black;

    for (int r = ul_r; r < (ul_r+height); r++)
    {
	for (int c = ul_c; c < (ul_c + width); c++)
	{
		int num_black = 0;
		bool diag = false;

		//bit_Quad calculation
		if (image[r][c] == 0)
		{
			num_black++;
		}
		if (image[r][c+1] == 0)
		{
			num_black++;
		}
		if (image[r+1][c] == 0)
		{
			num_black++;
		}
		if (image[r+1][c+1] == 0)
		{
			num_black++;
		}
			
		//classification for #black in each bit quad
		if(num_black == 0)
		{
			bit_quad[0]++;
		}
		if(num_black == 1)
		{
			bit_quad[1]++;
		}
		//Case for 2 blacks and diagonal
		if(num_black == 2 && (image[r][c] == image[r+1][c+1]) && (image[r][c+1]==image[r+1][c]))	
		{
			bit_quad[5]++;
			diag = true;
		}
		//2 blacks but non diagonal
		else if (num_black == 2 && !diag)
		{
			bit_quad[2]++;
		}	
		if(num_black == 3)
		{
			bit_quad[3]++;
		}
		if(num_black == 4)
		{
			bit_quad[4]++;
		}		
	}
    }
    return bit_quad;
}

int Character::calc_area()
{
	return height*width;
}

int Character::calc_perimeter()
{
	return 2*height+2*width;
}

double Character::calc_aspect_ratio()
{
	return (double)height/width;
}

double Character::calc_v_spatial_moment()
{
    int num_black = 0;
    double com = 0;
    double v_com;
    for (int r = 0; r < height; r++)
    {
	for (int c = 0; c < width; c++)
	{
		if (image[r+ul_r][c+ul_c] == 0)	
		{
			com += r;
			num_black += 1;
		}
	}
    }
    //vertical center of mass
    v_com = (double)com/num_black;
    return v_com;
}

double Character::calc_h_spatial_moment()
{
    int black = 0;
    double com = 0;
    double h_com;
    for (int r = 0; r < height; r++)
    {
	for (int c = 0; c < width; c++)
	{
		if (image[r+ul_r][c+ul_c] == 0)
		{
			com += c;
			black += 1;
		}
	}
    }
    //horizontal center of mass
    h_com = (double)com/black;
    return h_com;
}

double Character::calc_vert_sym()
{
    double matches = 0;
    int temp = 0;
    double total = 0;
    for (int i = ul_r; i < (ul_r+height); i++)
    {
	temp++;		//used to match symmetry across the vert center
	for (int j = ul_c; j < (ul_c + width); j++)
	{ 
		if(i < (ul_r+(height/2)))
		{
			total += 1;		//num pixels in half image
			if(image[i][j] == image[ul_r+height-temp][j])
			{	
				matches += 1;	//num matches
			}
		}
	}
    }
    return (double)matches/total;
}

double Character::calc_horz_sym()
{
    double matches = 0;
    int temp = 0;
    double total = 0;
    for (int r = ul_r; r < (ul_r+height); r++)
    {
	for(int c = ul_c; c < (ul_c + width); c++)
	{ 
		temp++;		//used to match symmetry across horiz center
		if(c < (ul_c+(width)/2))
		{
			total += 1;	//num pixels in half image
				
			if(image[r][c] == image[r][ul_c+width-temp])
			{	
				matches += 1;	//num pixels
			}
		}
	}
	temp = 0;
    }

    return (double)matches/total;
}


int Character::calc_euler_number()
{
	int euler = ((bit_quad[1]-bit_quad[3] - (2*bit_quad[5]))/4);
	return euler;
}

void Character::classify()
{
    double com_ratio = (double)h_com/v_com;

    perform_tests();
    if (euler == -2)
    {
	recognized_char = '8';
    }
    else if (euler == -1)
    {
	if(v_sym > 0.80 && h_sym > 0.80)
	{
		recognized_char = '0';
	}
	else
	{
		if(com_ratio >= 0.80)
		{
			recognized_char = '4';
		}
		else if (com_ratio >= 0.7 && com_ratio < 0.8)
		{
			recognized_char = '9';
		}
		else if (com_ratio >= 0.6 && com_ratio < 0.7)
		{
			recognized_char = '6';
		}
	}
    }
    else if (euler == 0)
    {
	if(com_ratio > 0.9 && aspect_ratio > 1.5)
	{
		recognized_char = '7';
	}
	else if (com_ratio < 0.5)
	{
		recognized_char = '1';
	}
	else
	{
		if(v_sym/h_sym >= 1)
		{
			recognized_char = '3';
		}
		else if (v_sym/h_sym > 0.9 && v_sym/h_sym < 1)
		{
			recognized_char = '2';
		}
		else if (v_sym/h_sym <= 0.9)
		{
			recognized_char = '5';
		}
	}
    }
}

char Character::get_classification()
{
	return recognized_char;
}

void Character::get_bounding_box(int &ulr, int &ulc, int &lrr, int &lrc)
{
	cout << "Character in bounding box: (" << ulc << "," << ulr << ") to (" << lrc <<"," << lrr << ")" << endl;
}

void Character::print_calculations()
{
    cout << "=============================================== " <<endl;
    perform_tests();
    cout << "Height: " << height << " Width: " << width << endl;
    cout << "Area: " << area << " Perimeter: " << perimeter <<endl;

    for (int i = 0; i < 6 ; i++)
    {
	cout << "BQ[" << i << "] = " << bit_quad[i] << "; ";
    }
    cout << endl;
    cout << "Euler number: " << euler+1 <<endl;
    cout << "Shifted COM: (" << v_com << "," << h_com << ")" << endl;
    cout << "Vert Sym: " << v_sym << " Horizontal Sym: " << h_sym <<endl;
    cout << "Aspect Ratio: " << aspect_ratio <<endl;
    

}

