/*----------------------------------
Name: Michael Chu
ID: 5708356882
email: chumc@usc.edu
class: ee355
-------------------------------------*/

#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <deque>
#include <cstdlib>
#include "character.h"
#include "point.h"
#include "bmplib.h"

using namespace std;

#define THRESH 127
unsigned char image[SIZE][SIZE];		// Input Image Data Array
unsigned char explored[SIZE][SIZE];		// Explored

void bounding_box(vector<Point> &myPoint, int *nums)
{
    for (int r = 0; r < SIZE; r++)
    {
    	    for (int c = 0; c < SIZE; c++)
	    {
		    int left = 256;
		    int right= 0;
		    int top = 256;
		    int bottom = 0;
		    if(image[r][c] == 0 && explored[r][c] == 255)
		    {
		    	    int head = 0; 
			    int tail = 0;
			    Point p(r,c);
			    deque<Point> deq; 
			    deq.push_back(p);
			    tail++;
	
			    while(tail>head)
			    {
				explored[(deq[head]).r][(deq[head]).c] = 0;
					
				if(image[(deq[head]).r][(deq[head]).c-1] == 0 && explored[(deq[head]).r][(deq[head]).c-1] == 255)//north
				{
				    Point p((deq[head]).r,(deq[head]).c-1);
				    explored[(deq[head]).r][(deq[head]).c-1] = 0;
				    deq.push_back(p);
				    tail++;
				}
			  	if(image[(deq[head]).r][(deq[head]).c+1] == 0 && explored[(deq[head]).r][(deq[head]).c+1] == 255)//south
				{
				    Point p((deq[head]).r,(deq[head]).c+1);
				    explored[(deq[head]).r][(deq[head]).c+1] = 0;
				    deq.push_back(p);
				    tail++;
				}
			        if(image[(deq[head]).r-1][(deq[head]).c] == 0 && explored[(deq[head]).r-1][(deq[head]).c] == 255)//west
				{
				    Point p((deq[head]).r-1, (deq[head]).c);
			    	    explored[(deq[head]).r-1][(deq[head]).c] = 0;
				    deq.push_back(p);
				    tail++;
				}
				if(image[(deq[head]).r+1][(deq[head]).c] == 0 && explored[(deq[head]).r+1][(deq[head]).c] == 255)//east
				{
				    Point p((deq[head]).r+1, (deq[head]).c);
				    explored[(deq[head]).r+1][(deq[head]).c] = 0;
				    deq.push_back(p);
				    tail++;
				}
				if(image[(deq[head]).r+1][(deq[head]).c-1] == 0 && explored[(deq[head]).r+1][(deq[head]).c-1] == 255)//ne
				{
			   	    Point p((deq[head]).r+1, (deq[head]).c-1);
				    explored[(deq[head]).r+1][(deq[head]).c-1] = 0;
				    deq.push_back(p);
				    tail++;
				}
			        if(image[(deq[head]).r-1][(deq[head]).c-1] == 0 && explored[(deq[head]).r-1][(deq[head]).c-1] == 255)//nw
				{
		  		    Point p((deq[head]).r-1, (deq[head]).c-1);
				    explored[(deq[head]).r-1][(deq[head]).c-1] = 0;
				    deq.push_back(p);
				    tail++;
				}
				if(image[(deq[head]).r+1][(deq[head]).c+1] == 0 && explored[(deq[head]).r+1][(deq[head]).c+1] == 255)//se
				{
				    Point p((deq[head]).r+1, (deq[head]).c+1);
				    explored[(deq[head]).r+1][(deq[head]).c+1] = 0;
				    deq.push_back(p);
				    tail++;
				}
				if(image[(deq[head]).r-1][(deq[head]).c+1] == 0 && explored[(deq[head]).r-1][(deq[head]).c+1] == 255)//sw
				{
				    Point p((deq[head]).r-1, (deq[head]).c+1);
				    explored[(deq[head]).r-1][(deq[head]).c+1] = 0;
				    deq.push_back(p);
				    tail++;
				}

			        if((deq[head]).r > right)
				{
					right = (deq[head]).r;
				}
				if ((deq[head]).r < left)
				{
					left = (deq[head]).r;
				}
				if((deq[head]).c < top)
				{
					top = (deq[head]).c;
				}
 			        if ((deq[head]).c > bottom)
				{
					bottom = (deq[head]).c;
				}
				head++;	
			    }
			
			    for (int y = 0; y < SIZE; y++)
			    {
				for (int x = 0; x < SIZE; x++)
				{
					if (x > left && x< right && y == top)	//top border
					{
						image[x][y] = THRESH;	
					}		
					if (x > left && x < right && y == bottom) //bottom border
					{
						image[x][y] = THRESH;
					}
					if (x == left && y < bottom && y > top ) //left border
					{
						image[x][y] = THRESH;
					}
					if (x == right && y < bottom && y > top) //right border
					{
						image[x][y] = THRESH;
					}	
				}		
			    }
			// top-left point
			Point c(left,top);
			myPoint.push_back(c);
				
			// bottom-right point
			Point d(right, bottom);
			myPoint.push_back(d);
			*nums += 1;
				
	    	    }//end of while
	    }	//end of 1st for
    }	//end of 2nd for
    showGSBMP(image);
} 


int main(int argc, char *argv[])
{
    readGSBMP(argv[1], image);
    readGSBMP(argv[1], explored);

    if (argc < 2)
    {
	cout << "ERROR. Enter <Executable> <image file> <0 or 1 to see debug> "<<endl;
	return -1;
    }
    int compare = atoi(argv[2]);
    int nums = 0;
    vector<Point> myPoint;
    for(int y=0; y < SIZE; y++)
    {
	for(int x = 0; x < SIZE; x++)
	{
	    explored[x][y] = 255;	//clearing out explored image
	    if (image[x][y] < 127)
   	    {
		image[x][y] = 0;
	    }
	    else
	    {
		image[x][y] = 255;
	    }
	}
    }
    bounding_box(myPoint, &nums); 
		
    int count = 1;	

    for (int i = 0; i < myPoint.size(); i=i+2)
    {	    
	if (compare == 1)
	{
	    Character debug(explored,(myPoint[i]).r, (myPoint[i]).c, ((myPoint[i+1]).r-(myPoint[i]).r+1), ((myPoint[i+1]).c-(myPoint[i]).c+1));
	    debug.get_bounding_box((myPoint[i]).r, (myPoint[i]).c, (myPoint[i+1]).r,(myPoint[i+1]).c);
	    debug.print_calculations();	  
	    debug.classify();
	    cout << "Character " << left <<  setw(2) << count << " is classified as: " << debug.get_classification() <<endl << endl;
	    count++;
	}
	else if (compare == 0)
	{
  	    Character debug(explored,(myPoint[i]).r, (myPoint[i]).c, ((myPoint[i+1]).r-(myPoint[i]).r+1), ((myPoint[i+1]).c-(myPoint[i]).c+1));
	    debug.perform_tests();
	    debug.classify();
	    cout << "Character " <<left << setw(2) << count << " is classified as: " << debug.get_classification() << endl;
            count++;
	}
	else
	{
	    cout << "ERROR: Enter 0 or 1 as argv[2] "<< endl;
	    break;
	}
     }
  return 0;
}
