#ifndef CHARACTER_H
#define CHARACTER_H
#include "point.h"

class Character {
 public:
  Character();
  // the first parameter should just be passed in and saved to 
  //  the 'image' data member as in ( image = myimage; )
  Character(unsigned char (*myimage)[256], int ulr, int ulc, int h, int w );
  ~Character(); 


  void perform_tests();
  void classify();
  char get_classification();
  // returns upper-left point and lower-right point of bounding box
  //  DOES NOT compute bounding box...it's already in your data members
  //  just returns the bounding box if a user wants the bounds
  void get_bounding_box(int &ulr, int &ulc, int &lrr, int &lrc);
  void print_calculations();

 private:
  //==============
  // Helper Functions
  //==============

  int *calc_bit_quads();
  int calc_area();
  int calc_perimeter();
  int calc_euler_number();
  double calc_v_spatial_moment(); // calcs the horizontal & vertical centroids
  double calc_h_spatial_moment();
  double calc_vert_sym();            // calcs horizontal and vertical symmetry
  double calc_horz_sym();
  double calc_aspect_ratio();

  //==============
  // Data Members
  //==============
 private: 
  int ul_r, ul_c;
  int height, width;
  
  // feel free to add functions here.
  int bit_quad[6];	//0b, 1b, 2 non-d b, 3 b, 4 b, 2 dia b
  int area;
  int perimeter;
  int euler;
  double v_com;
  double h_com;
  double v_sym;
  double h_sym;
  double aspect_ratio;
  char value;
  char recognized_char;
  unsigned char (*image)[256];


};

#endif

