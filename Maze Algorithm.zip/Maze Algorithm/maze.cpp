#include <iostream>
#include "maze_io.h"
using namespace std;

// Prototype for maze_search
int maze_search(char *, int, int);

int main(int argc, char *argv[])
{
  int rows, cols, result;
  char *mymaze;

  if(argc < 3){
    cerr << "Usage: ./maze in_filename out_filename" << endl;
    return 1;
  }

  mymaze = read_maze(argv[1], &rows, &cols);

  // For checkpoint 1, just leave maze_search() unedited
  //  and the program should read in the maze, print it
  //  and write it back to the output file
  result = maze_search(mymaze, rows, cols);

  if( result == 1 ){
    cout << "Path successfully found!" << endl;
    print_maze(mymaze,rows,cols);
    write_maze(argv[2],mymaze,rows,cols);
  }
  else if (result == 0) {
    cout << "No path could be found!" << endl;
  }
  else {
    cout << "Error occurred during search!" << endl;
  }

  delete [] mymaze;

  return 0;
}

/**************************************************
 * Attempt to find shortest path and return:
 *  1 if successful
 *  0 if no path exists
 * -1 if an error occurred (no start of finish
 *     cell present in the maze)
 *
 * If path is found fill it in with '*' characters
 *  but don't overwrite the 'S' and 'F' cells
 *************************************************/
int maze_search(char *maze, int rows, int cols)
{
   int len = rows*cols;
   int a, b, idx, comp1, comp2, star;
   int found = 0;
   int head = 0;
   int tail = 0;
   int* pre = new int[len];		//dynamically allocate a predecessor array
   int* stack = new int[len];
   bool start = false;
   bool finish = false;

   for (int i = 0; i < rows; i++)		
   {
	for (int j = 0; j < cols; j++)
	{
		if (maze[i*cols+j] == 'S')		//searches for start
		{
			stack[tail] = i*cols + j;	//If found, starts the stack (queue)
			pre[i*cols+j] = -2;		//makes S of predecessor array -2
			tail++;	
			start = true;
		}
		if (maze[i*cols+j] == 'F')
		{
			finish = true;				
		}
		else
		{
			pre[i*cols + j] = -1;		//makes predecessor array of all -1
		}
	}
   }
	
   if (!start || !finish)				//checks to make sure we have an S and F
   {
	delete [] pre;
	delete [] stack;
	return -1;
   }

   while (tail>head && found == 0)			//loop searches for next "."
   {
	for (a = 0; a < rows; a++)			//searches in 2D
	{
	    for (b = 0; b < cols; b++)
	    {
		idx = a*cols+b;				//Equation for a 2D array in 1D
		comp1 = idx/cols;			//comp1 checks to make sure we move in the same row
		comp2 = idx%cols;			//comp2 checks to make sure we move in the same column
		if((idx) == stack[head])		//Algorithm that searches for the "head" of the queue
		{
		    //The following 4 if's check if we find the 'F' in any adjacent location
		     if ((maze[idx+cols] == 'F') && (((idx+cols)/cols == comp1)||((idx+cols)%cols == comp2)))
		    {
			found = 1;
			stack[tail] = idx+cols;
			pre[idx+cols] = stack[head];	//We don't increment Tail as we have reached the end
			break;
		    }

		    if ((maze[idx-1]  == 'F') && (((idx-1)/cols == comp1)||((idx-1)%cols == comp2)))
		    {
			found = 1;
			stack[tail] = idx-1;
			pre[idx-1] = stack[head];
			break;
		    }

		    if ((maze[idx-cols]  == 'F') && (((idx-cols)/cols == comp1)||((idx-cols)%cols == comp2)))
		    {
			found = 1;
			stack[tail] = idx-cols;
			pre[idx-cols] = stack[head];
			break;
		    }

		    if ((maze[idx+1]  == 'F') && (((idx+1)/cols == comp1)||((idx+1)%cols == comp2)))
		    {
			found = 1;
			stack[tail] = idx+1;
			pre[idx+1] = stack[head];
			break;
		    }
		  
	
		    //These essentially check the adjancent location in the same row/column (NWSE) and if predecessor hasn't visited yet
		    //In summary, if statements work as:
		    //if(maze[North] is a '.', and we haven't been there yet (pre[] = -1), and in same row and column
		    if((maze[idx+cols] =='.') && (pre[idx+cols]==-1) && (((idx+cols)/cols == comp1)||((idx+cols)%cols == comp2)))
		    {
			//North
		 	stack[tail] = idx+cols;
			tail += 1;
			pre[idx+cols] = stack[head]; 			
    		    }

		    if((maze[idx-1] =='.') && (pre[idx-1]==-1) && (((idx-1)/cols == comp1)||((idx-1)%cols == comp2)))
		    {
			//West
			stack[tail] = idx-1;
			tail += 1;
			pre[idx-1] = stack[head]; 
		    }	

		    if((maze[idx-cols] =='.') && (pre[idx-cols]==-1) && (((idx-cols)/cols == comp1)||((idx-cols)%cols == comp2)))
		    {
			//South
			stack[tail] = idx-cols;
			tail += 1;
			pre[idx-cols] = stack[head]; 
		    }

		    if((maze[idx+1] =='.') && (pre[idx+1]==-1) && (((idx+1)/cols == comp1)||((idx+1)%cols == comp2)))
		    {
			//East
			stack[tail] = idx+1;
			tail += 1;	
			pre[idx+1] = stack[head]; 
		    }
		  
		break;
		}
	    }
	} 
   head += 1;						//increments after checking loop for current head
   }

//****************************************************
//*         STAR OUTPUT ON FINALIZED MAZE	     *
//****************************************************
	
   if (found == 1)
   {
	star = pre[stack[tail]] ;			//Sets star to check predecessors 
	maze[star] = '*';				//Sets location adjacent to F as '*'
	while (pre[star] != stack[0])			//Loop has each star walk backwards using predecessor array values
	{
	    star = pre[star];
	    maze[star] = '*';
	}
	delete [] stack;
  	delete [] pre;					//Deallocate pre array
  	return 1;
   }
   else
   {
	delete [] stack;
	delete [] pre;
	return 0;
   }
}

