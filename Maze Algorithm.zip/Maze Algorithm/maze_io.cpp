/*------------------------------------------------------------------------------------------- 
|  NAME: MICHAEL CHU									     |
|  COURSE: EE355									     |
|  ID: 5708356882									     |
|  SUMMARY: This segment of the code contains functions relating to extracting contents from |
|	    the input file, outputting the correct path to the screen, and outputting the    |
|	    solved path into an output file.						     |
---------------------------------------------------------------------------------------------*/
#include <iostream>
#include <fstream>
#include "maze_io.h"

using namespace std;

/*************************************************
 * Open the file specified by filename, and read the 
 * maze into a dynamically allocated array.
 * 
 * Return the pointer to that array (don't delete it..
 * we'll do that in main() ).  Return NULL if
 * you are unable to open the file or can't read
 * the dimensions.
 *
 * We also pass in two pointers to integers. Fill 
 *  those values in with the number of rows and 
 *  columns read by from the file (first two value
 *  in the file)
 *
 *************************************************/

char * read_maze(char *filename, int *rows, int *cols )
{
	ifstream ifile(filename);
	if (ifile.fail())
	{
		cout<< "Please provide input file";
		return NULL;
	}

	ifile >> *rows >> *cols;	//places rows & columns(1st 2 #s) into the pointer, so the actual value changes globally
	if (ifile.fail())
	{
		cout << "Can't read two integers for rows/cols";
		return NULL;
	}
	int temp1 = *rows;		//temp allocates rows into an int
	int temp2 = *cols;		//temp allocates cols into an int
	int len = temp1 * temp2;	//can't multiply two pointers together... so just multiply the contents
	char* maze_contents = new char[len];

	for (int i = 0 ; i < len; i++)
	{
		for (int j = 0; j < len; j++)
		{
			ifile >> maze_contents[i*temp2 + j];	//import file contents into maze_content array
		}
	}
	ifile.close();
	return maze_contents;		//return pointer maze
}

/*************************************************
 * Print the maze contents in a 2D format to the
 * screen
 *
 *************************************************/
void print_maze(char *maze, int rows, int cols)
{
	for (int i = 0; i < rows ; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			cout << maze[i*cols+j];
		}
		cout << endl;
	}

}

/*************************************************
 * Write maze should open the file specified by 
 * filename and write the contents of the maze
 * array to the file with the dimensions on the first
 * line.
 *
 *************************************************/
void write_maze(char *filename, char *maze, int rows, int cols)
{
	ofstream ofile(filename);
	if (ofile.fail())
	{
		cout << "Please enter valid output file.";
			
	}
	ofile << rows << " " << cols << endl;
	for (int i = 0; i < rows ; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			ofile << maze[i*cols+j];	//outputs array contents into file
		}
		ofile << endl;
	}

}
