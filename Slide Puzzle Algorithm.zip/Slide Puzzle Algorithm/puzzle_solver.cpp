#include <vector>
#include <deque>
#include <set>
#include "board.h"
#include "puzzle_move.h"
#include "puzzle_heur.h"
#include "puzzle_solver.h"
#include "heap.h"
#include <iostream>

using namespace std;

PuzzleSolver::PuzzleSolver(const Board& b, PuzzleHeuristic *ph) : _b(b) 
{
	_b = b;
	_ph = ph;
	_expansions = 0;
}

PuzzleSolver::~PuzzleSolver()
{

}

// Run the A* search
void PuzzleSolver::run()
{
	PuzzleMove p(&_b);				//places parent into PuzzleMove (closed)
	PuzzleMoveHeap openlist;			//non-explored puzzlemove*
	PuzzleMoveSet closedlist;			//explored puzzlemove*
	openlist.push(&p);				//places first board orientation (aka start state)
	closedlist.insert(&p);				//initializes start state as explored
	PuzzleMove* minstate = openlist.top();

	//while the openlist s not empty, and we haven't solved it yet
	while(!openlist.empty() && !((minstate->b)->solved()))
	{

		minstate = openlist.top();	//lowest minstate
		openlist.pop();			//pops front item

		if (minstate->b->solved())	//if we solved the puzzle
		{
			//trace backwards 
			while(minstate->prev != NULL)
			{
				_solution.push_front(minstate->tileMove);
				minstate = minstate->prev;
			}
			while(!openlist.empty())
			{
				delete openlist.top()->b;
				openlist.pop();
			}		
			/*while(!closedlist.empty())
			{
				delete (*closedlist.begin())->b;
				closedlist.erase(closedlist.begin());
			}*/
			
			closedlist.clear();
			break;
		}
		
		map<int, Board*> potential_moves = (minstate->b->potentialMoves());
		map<int, Board*>::iterator it;

		//adds next potential tile moves for board by iterating through potentialMoves
		for(it = potential_moves.begin(); it != potential_moves.end(); ++it)
		{
			PuzzleMove* s = new PuzzleMove(it->first, it->second, minstate);		
			
			s->score(_ph);					//compute f value for s
				
			if(closedlist.find(s) == closedlist.end())	//if not inside closed list
			{
				openlist.push(s);  			//adds to open list
				closedlist.insert(s);			//adds to closed list
				_expansions++;
			}
			else
			{
				delete s;
			}				
		}
	}
}



// Return the solution deque
deque<int> PuzzleSolver::getSolution()
{
	return _solution;
}

int PuzzleSolver::getNumExpansions()
{
	return _expansions;
}


