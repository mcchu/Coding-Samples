#include "board.h"
#include <math.h>
#include <cmath>
#include "puzzle_heur.h"

using namespace std;

int PuzzleManhattanHeuristic::compute(const Board& b)
{
	int dimension = b.getDim();
	int size = b.getSize();
	int dx, dy, current_col, current_row;
	int total_distance = 0; //moving tile in x or y direction
	for (int i = 0; i < size; i++)
	{
		dx = i%dimension;	//destination column
		dy = i/dimension;	//destination row
		if (b.getTile(i) != 0)
		{
			current_col = b.getTile(i)%dimension;
			current_row = b.getTile(i)/dimension;
			total_distance += abs(current_col - dx);
			total_distance += abs(current_row - dy);	
			//manhattan distance = diff between idx and solvedpuzz	
		}		
	}
	return total_distance;
}


int PuzzleOutOfPlaceHeuristic::compute(const Board& b)
{
	int size = b.getSize();
	int out_of_place = 0;
	for (int idx = 0; idx < size; idx++)
	{
		if (b.getTile(idx) != idx && b.getTile(idx) != 0)
		{
			out_of_place++;
		}
	}
  return out_of_place;
}


int PuzzleBFSHeuristic::compute(const Board& b)
  {
	//this function gives NO heuristic
	return 0;
  }
