#include <iostream>
#include <iomanip>
#include <map>
#include <math.h>
#include <cmath>
#include <cstdlib>
#include "puzzle_move.h"
#include "puzzle_heur.h"
#include "board.h"

using namespace std;

// Constructor for first Move (initial board) with no parent or tileMove
PuzzleMove::PuzzleMove(Board *board)
{
	b = board;			//
	h = 0;				//initial heuristic  <-------------
	g = 0;				// 
	prev = NULL;			//

}

// Constructor for subsequent search boards 
//input: (tile, current board, parent)
PuzzleMove::PuzzleMove(int tile, Board *board, PuzzleMove *parent)
{
	tileMove = tile;		//moves this tile
	b = board;			//
	prev = parent;			//allocates parent as previous
	g = (prev->g) + 1;		//
}

void PuzzleMove::score(PuzzleHeuristic* ph)
{	
	h = ph->compute(*b);
}

// Destructor
PuzzleMove::~PuzzleMove()
{
	
}

bool PuzzleMove::operator<(const PuzzleMove& p) const
{
	if ((g+h) < (p.g + p.h))
	{
		return true;
	}
	else if ((g+h) == (p.g + p.h))
	{
		if(h < p.h)
		{
			return true;
		}
		else if(h > p.h)
		{		
			return false;
		}
	}

	return false;
}


