#include <iostream>
#include <cstdlib>
#include <deque>
#include "board.h"
#include "puzzle_heur.h"
#include "puzzle_solver.h"

int main(int argc, char *argv[])
{
  if(argc < 5){
    cerr << "Usage: ./puzzle size initMoves seed heur" << endl;
    return 1;
  }

  int size, initMoves, seed, heur;
  //input = ./puzzle size initial-scramble-moves random-num-generator heuristic
  size = atoi(argv[1]);		
  initMoves = atoi(argv[2]);
  seed = atoi(argv[3]);
  heur = atoi(argv[4]);

  int input;

  Board b(size,initMoves,seed);
 
  PuzzleHeuristic* ph;
  if(heur == 0){
      ph = new PuzzleBFSHeuristic;
  }
  else if(heur == 1){
      ph = new PuzzleOutOfPlaceHeuristic;		//works
    }
  else {
    ph = new PuzzleManhattanHeuristic;			//works
   } 

  //*********** Implement the gameplay here************************
  PuzzleSolver p(b, ph);
  cout << b;
 
  do
  {
	cout << "Enter tile number to move, 0 to exit, or -1 for a cheat: ";
	cin >> input;
	if(input == -1)
	{
		p.run();
		deque<int> x = p.getSolution();
		cout << "Try this sequence: " ;
		for (unsigned int i = 0; i < x.size(); i++)
		{
			cout << x[i] << " ";
		} 

		cout << endl;
		cout << "(Expansions = " << p.getNumExpansions() << ") " << endl;

	}
	else if (input == 0)
	{
		cout << "\n Now exiting puzzle. " << endl << endl;
		break;
	}
	else
	{
		b.move(input);
		cout << b;

		if (b.solved() == true)
		{
			cout << "Congratulations, you finished the puzzle!" << endl;
			break;
		}
	}	
  }while(input != 0);

  delete ph;

  return 0;
}
